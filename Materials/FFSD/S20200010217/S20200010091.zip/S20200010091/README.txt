Name : Rahul Katinni.
Rollno: S20200010091.


1. Inorder to run the code we need to istall the following node packages.
	a) express
	b) nodemon
	c) ejs
	d) mysql

	The comands to install are: 

	a) npm install ejs express mysql
	b) npm intall -g nodemon

2. Then open the MySql Workbench and import the database form the dump file.

3. Then in any code editor open S20200010091_index.js file and in the line no. 8, change the password to your sql password.

4. Then in the terminal change the directory to the folder in which the files are present and run the command 
	nodemon S20200010091_index.js

5. Now open any browers and open localhost:3000 in the url bar.