const User = require('../models/userModel')
const Product = require('../models/productModel')
const Cart = require('../models/cartModel')
const ErrorHandler = require('../utils/errorHandler')
const catchAsyncErrors = require('../middleware/catchAsyncErrors')

exports.getAllCartItems = catchAsyncErrors(async(req, res) =>{
    // console.log('hello');
    const id = req.user._id;
    // console.log(id);
    const cart = await Cart.findOne({user:id})
    let cartItems=[]
    let quantity_arr = []
    let subTotal = 0
    let tax = 0
    let total = 0
    for(let i =0;i<cart.cartItems.length;i++){
        const id = cart.cartItems[i]._id;
        const product = await Product.findById(id)
        quantity_arr.push(cart.cartItems[i].quantity)
        cartItems.push(product)

        subTotal += product.price * quantity_arr[i]
    }

    tax = subTotal/20
    total = tax + subTotal

    if(!cartItems) {
        return next(new ErrorHandler("cart not found", 404))
    }

    res.status(200).render('cart', {cartItems, quantity_arr, subTotal, tax, total})
})
