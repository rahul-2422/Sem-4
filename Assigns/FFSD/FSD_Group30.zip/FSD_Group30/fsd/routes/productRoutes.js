const express = require('express')
const { getAllCartItems } = require('../controllers/cartController')
const { getAllProducts, createProduct, updateProduct, deleteProduct, getProductDetails, createProductReview, deleteReview, getProductReviews, addToCart, deleteCartItem, getProduct } = require('../controllers/productController')
const { isAuthenticatedUser, isAllowed } = require('../middleware/auth')

const router = express.Router()

 
router.route('/products').get( isAuthenticatedUser, getAllProducts)

router.route('/admin/product/new').post(isAuthenticatedUser, isAllowed('admin'), createProduct) 

router.route('/admin/product/:id').put(isAuthenticatedUser, isAllowed('admin'),updateProduct)

router.route('/admin/product/:id').delete(isAuthenticatedUser, isAllowed('admin'), deleteProduct)

router.route('/product/:id').get(isAuthenticatedUser, getProductDetails).post(isAuthenticatedUser, addToCart, getProductDetails).put(isAuthenticatedUser, deleteCartItem)

router.route('/addReview/:id').post(isAuthenticatedUser, createProductReview)

router.route('/addReview/:id').get(isAuthenticatedUser, getProduct)

router.route('/me/cart').get(isAuthenticatedUser, getAllCartItems).put(isAuthenticatedUser, deleteCartItem)

router.route('/me/cart/:id').post(isAuthenticatedUser, addToCart, getAllCartItems)

router.route('/me/cart/delete/:id').post(isAuthenticatedUser, deleteCartItem, getAllCartItems)

router.route('/review').put(isAuthenticatedUser, createProductReview)

router.route('/review').get(isAuthenticatedUser, getProductReviews)

router.route('/review').delete(isAuthenticatedUser, deleteReview)

module.exports  = router