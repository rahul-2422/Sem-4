const express = require('express')
const { getAllCartItems } = require('../controllers/cartController')

const { getAllProducts, createProduct, updateProduct, deleteProduct, getProductDetails, createProductReview, deleteReview, getProductReviews } = require('../controllers/productController')
const { isAuthenticatedUser, isAllowed } = require('../middleware/auth')

const router = express.Router()

router.route('/cart').get(isAuthenticatedUser, getAllCartItems)

module.exports = router