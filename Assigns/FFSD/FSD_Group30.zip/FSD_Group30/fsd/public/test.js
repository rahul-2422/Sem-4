let cartDetails = document.querySelector('.all-cart-details-box');
let SubTotal = document.querySelector("#subtotal");
let Tax = document.querySelector("#tax");
let Shipping = document.querySelector("#shipping");
let GrandTotal = document.querySelector("#grandtotal");

let CartItems = document.querySelectorAll(".individual-cart-item-box");

CartItems.forEach(item => {
    item.child(".individual-cart-item").child(".row").child(".Product-quantity").change(function(){
        updateQuantity(this);
    });
});

CartItems.forEach(item => {
    item.child(".individual-cart-item").child(".row").child(".Product-delete").click(function(){
        removeItem(this);
    });
});

function recalculateCart(){
    let subtotal = 0;
    let taxRate = 0.05;

    CartItems.forEach(item => {
        subtotal += parseFloat(item.child(".individual-cart-item").child(".row").child(".Product-cost-box").child(".Product-cost").text());
    });

    if(subtotal < 3000){
        Shipping.innerText = "150";
    }
    else Shipping.innerText = "0";
    let tax = subtotal * taxRate;
    let shipping = (subtotal > 0 ? 150 : 0);
    let total = subtotal + tax + shipping;

    SubTotal.innerText = `${subtotal}`;
    Tax.innerText = `${tax}`;
    Shipping.innerText = `${shipping}`;
    GrandTotal.innerText = `${total}`;
}

function updateQuantity(quantityInput) {
    let productRow = quantityInput.parent().parent();
    let price = productRow.child(".Product-cost-box").child(".Product-cost").text();
    let quantity = quantityInput.val();
    let newPrice = price * quantity;

    productRow.child('.Product-cost-box').child('.Product-cost').each(function (){
        this.fadeOut(fadeTime, function(){
            this.innerText = newPrice;
            recalculateCart();
            this.fadeIn(fadeTime);
        });
    });
}

function removeItem(removeButton) {
    let productRow = removeButton.parent();
    productRow.slideUp(fadeTime, function(){
        productRow.remove();
        recalculateCart();
    });
}