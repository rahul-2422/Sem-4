var taxRate = 0.05;
var shippingRate = 0;
var fadeTime = 100;

