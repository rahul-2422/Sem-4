var taxRate = 0.05;
var shippingRate = 0; 
var fadeTime = 100;
$('.product-quantity .Buttons').click( function() {
  updateQuantity(this);
});

$('.product-removal button').click( function() {
  removeItem(this);
});


function recalculateCart()
{
  var subtotal = 0;
  
  $('.product').each(function () {
    subtotal += parseFloat($(this).children('.product-line-price').text());
  });
  if (subtotal <3000) {
    window.shippingRate = 150;
    alert("Shipping charges of ₹150 applicable on orders below ₹3000")
  }
  else window.shippingRate = 0;
  var tax = subtotal * taxRate;
  var shipping = (subtotal > 0 ? shippingRate : 0);
  var total = subtotal + tax + shipping;
  $('.totals-value').fadeOut(fadeTime, function() {
    $('#cart-subtotal').html(subtotal.toFixed(2));
    $('#cart-tax').html(tax.toFixed(2));
    $('#cart-shipping').html(shipping.toFixed(2));
    $('#cart-total').html(total.toFixed(2));
    if(total == 0){
      $('.checkout').fadeOut(fadeTime);
    }else{
      $('.checkout').fadeIn(fadeTime);
    }
    $('.totals-value').fadeIn(fadeTime);
  });
}


function updateQuantity(quantityInput)
{
  var productRow = $(quantityInput).parent().parent().parent();
  var price = parseFloat(productRow.children('.product-price').text());
  var quantity = $(quantityInput).val();
  var linePrice = price * quantity;

  productRow.children('.product-line-price').each(function () {
    $(this).fadeOut(fadeTime, function() {
      $(this).text(linePrice.toFixed(2));
      recalculateCart();
      $(this).fadeIn(fadeTime);
    });
  });  
}


function removeItem(removeButton)
{
  var productRow = $(removeButton).parent().parent();
  productRow.slideUp(fadeTime, function() {
    productRow.remove();
    recalculateCart();
  });
}



















// const cart = querySelector(".all-cart-details");

// (cart).ready(function() {

// let taxRate = 0.05;
// let shippingRate = 0; 
// let fadeTime = 100;

// querySelector('.Product-quantity input').change( function() {
//   updateQuantity(this);
// });

// querySelector('.Product-delete ').click( function() {
//   removeItem(this);
// });

// function recalculateCart()
// {
//     let subtotal = 0;

//     querySelector('.individual-cart-item').each(function(){
//         subtotal += parseFloat($(this).children('.Product-cost-box').children(".Product-cost").text())
//     });
//     if(subtotal < 3000) {
//         Document.shippingRate = 150;
//     }
//     else Document.shippingRate = 0;

//     let tax = subtotal * taxRate;
//     let shipping = (subtotal > 0 ? shippingRate : 0);
//     let total = subtotal + tax + shipping;

//     querySelector('.detail-values').fadeOut(fadeTime, function() {
//         querySelector('#subtotal').html(subtotal.toFixed(2));
//         querySelector('#tax').html(tax.toFixed(2));
//         querySelector('#shipping').html(shipping.toFixed(2));
//         querySelector('#grandtotal').html(total.toFixed(2));
//         if(total == 0){
//             querySelector('.cart-checkout').fadeOut(fadeTime);
//         }else{
//             querySelector('.cart-checkout').fadeIn(fadeTime);
//         }
//         querySelector('.detail-values').fadeIn(fadeTime);
//     });
// }

// function updateQuantity(quantityInput) {
//     let productRow = querySelector(quantityInput).parent().parent();
//     let price = parseFloat(productRow.children('.Product-cost-box').children('.Product-cost').text());
//     let quantity = querySelector(quantityInput).val();
//     let linePrice = price * quantity;

//     productRow.children('.Porduct-cost-box').children('.Product-cost').each(function(){
//         querySelector(this).fadeOut(fadeTime, function(){
//             querySelector(this).text(linePrice.toFixed(2));
//             recalculateCart();
//             querySelector(this).fadeIn(fadeTime);
//         });
//     });
// }

// function removeItem(removeButton){
//     let productRow = querySelector(removeButton).parent().parent();
//     productRow.slideUp(fadeTime, function(){
//         productRow.remove();
//         recalculateCart();
//     });
// }

// })