README
-------------
Survey Question No: 19
Prerequisite: Install Node

Please install the following packages:

npm init
npm install modules
npm install ejs express body-parser sqlite3
npm i -g nodemon

Run the application:
nodemon index.js

Open the following link
http://localhost:3000/
