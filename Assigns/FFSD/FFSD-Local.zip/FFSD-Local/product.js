// const next = document.querySelector(".all-product-images .next-button button");
// const back = document.querySelector(".all-product-images .back-button button");
// const view = document.querySelector(".all-product-images .images-container");

// let viewChange = 0;

// next.addEventListener(onclick, function(){
//     viewChange += 10;
//     let x = `translate(-${viewChange}rem, 0px)`
//     view.style.transform = x;
// });

// back.addEventListener(onclick, () => {
//     viewChange -= 10;
//     let y = `translate(-${viewChange}rem, 0px)`
//     view.style.transform = y;
// })



const imgBox = document.querySelectorAll(".images-container img");
const img = document.querySelector(".product-current-image");


